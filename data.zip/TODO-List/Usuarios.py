class usuario:
    def __init__(self,id_usuario,nombre,departamento):
        self.id_usuario=id_usuario
        self.nombre=nombre
        self.departamento=departamento
        
        