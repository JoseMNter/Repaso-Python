class tarea:
    def __init__(self,id_tarea,nombre,descripcion):
        self.id_tarea=id_tarea
        self.nombre=nombre
        self.descripcion=descripcion
        
    