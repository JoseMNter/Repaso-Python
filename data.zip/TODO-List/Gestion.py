import Tareas,Usuarios
from datetime import datetime


class gestion:
    def __init__(self):
        self.listaTareas=[]
        self.listaUsuarios=[]
        self.tareasAsignadas=[]
        
    def agregarTarea(self,tarea_id,nombre_tarea,descrip_tarea):
    
        tarea = {
            'tarea_id': tarea_id,
            'nombre_tarea': nombre_tarea,
            'descrip_tarea': descrip_tarea
        }
        self.listaTareas.append(tarea)
    
    def agregarUsuario(self,id_usuario,nombre,departamento):
        
        usuario = {
            'id_usuario': id_usuario,
            'nombre': nombre,
            'departamento': departamento
        }
        self.listaUsuarios.append(usuario)
    
    def listar_tareas(self):
        
        if not self.listaUsuarios:  
            print("No hay tareas registradas.")
        else:
            print("--- Lista de tareas registradas ---")
        for tarea in self.listaTareas:
            print(f"ID: {tarea['tarea_id']}, Nombre: {tarea['nombre_tarea']}, Descripción: {tarea['descrip_tarea']}")
        print(" ")
    
    def listar_usuarios(self):
       
        if not self.listaUsuarios:  
            print("No hay usuarios registrados.")
        else:
            print("--- Lista de usuarios registrados ---")
        for usuario in self.listaUsuarios:
            print(f"ID: {usuario['id_usuario']}, Nombre: {usuario['nombre']}, Departamento: {usuario['departamento']}")
        print(" ")


    
    def eliminar_tarea(self,id_tarea):
        
        for tarea in self.listaTareas:
            
            if tarea.id == id_tarea:
                
                self.listaTareas.remove(tarea)
                return "Tarea eliminada satisfactoriamente.\n"
                
        return "Tarea no encontrada.\n"
    
    def eliminar_usuario(self,id_usuario):
        
        for usuario in self.listaUsuarios:
            
            if usuario.id_usuario == id_usuario:
                
                self.listaUsuarios.remove(usuario)
                return "Usuario eliminado satisfactoriamente.\n"
                
        return "Usuario no existe.\n"
    
    def buscarUsuarioPorId(self,id_usuario):
        
        for usuario in self.listaUsuarios:
            
            if usuario["id_usuario"] == id_usuario:
                
                return usuario
            
        return None
            
            
    
    def buscarTareaPorId(self,id_tarea):
        
        for tarea in self.listaTareas:
            
            if tarea.id_tarea == id_tarea:
                
                return tarea
                
        return "Tarea no encontrada.\n"
            
    
    def actualizarDepartamentoDelUsuario(self,id_usuario):
        
         for usuario in self.listaUsuarios:
            
            if usuario.id == id_usuario:
                
                nuevo_departamento = input("Introduce el nuevo departamento.")
                
                usuario.departamento = nuevo_departamento
                
                return "Departamento actualizado exitósamente.\n"
            
            else:
                
                return "Usuario no encontrado.\n"
            
    def actualizarTarea(self,id_tarea):
        
        for tarea in self.listaTareas:
            
            if tarea.id == id_tarea:
                
                try:
                    
                    opcion=int(input("Elige una opción:\n1) Cambiar nombre\n2) Cambiar descripción\n 3) Cambiar importancia"))
                    
                    match opcion:
                        
                        case 1:
                            
                            nuevo_nombre=input("Introduce el nuevo nombre de la tarea: ")
                            
                            print(f"Nombre cambiado de {tarea.nombre} a {nuevo_nombre}")
                            
                            tarea.nombre = nuevo_nombre
                            
                        case 2:
                            
                            nueva_descripcion=input("Introduce la nueva descripción de la tarea: ")
                            
                            print(f"Descripción antigua:\n{tarea.descripcion}\nDescripción nueva:\n{nueva_descripcion}")
                            
                            tarea.descripcion = nueva_descripcion
                            
                        case 3:
                            
                            while True:
                                
                                nueva_importancia=int(input("Mínimo 1, máximo 3"))
                                
                                if 1 <= nueva_importancia <= 3:
                                    
                                    print("Se ha cambiado la importancia exitosamente.\n")
                                    
                                    tarea.importancia = nueva_importancia
                                    
                                else:
                                    
                                    print("Por favor, introduce un valor correcto entre 1 y 3.")
                
                        case _:
                            
                            print("Introduce una opción válida.")
                        
                except ValueError:
                    
                    print("Tienes que introducir un valor númerico para que funcione bien la aplicación")
                    
            return "Tarea no encontrada.\n"
        
        return "Tarea no encontrada.\n"
    
    def asignarTarea(self, id_asignacion, tarea, usuario):
        fecha = datetime.now()
        
        asignacion = {
            "id_asignacion": id_asignacion,
            "tarea": tarea,
            "usuario": usuario,
            "fecha": fecha
        }
        
        self.tareasAsignadas.append(asignacion)

        
            
    
    
    