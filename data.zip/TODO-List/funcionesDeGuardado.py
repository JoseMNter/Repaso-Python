import json
import os

# Función para guardar usuarios en un archivo JSON
def guardar_usuarios_en_json(lista_usuarios, ruta_json):
    # Si la carpeta no existe, la creamos
    carpeta = os.path.dirname(ruta_json)
    if not os.path.exists(carpeta):
        os.makedirs(carpeta)
    
    # Guardamos los usuarios en el archivo JSON
    with open(ruta_json, 'w', encoding='utf-8') as json_file:
        json.dump(lista_usuarios, json_file, ensure_ascii=False, indent=4)
